#include "tempsvalide.h"

// Fonction pour v�rifier si une date est valide
int DateValide(int jour, int mois, int annee) {
    // Tableau indiquant le nombre de jours dans chaque mois
    const int NbJoursparMois[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    // V�rifie si le mois est dans la plage autoris�e
    if (mois < MONTH_MIN || mois > MONTH_MAX) {
        return 0; // Mois invalide
    }

    // V�rifie si le jour est dans la plage autoris�e pour le mois sp�cifi�
    if (jour < 1 || jour > NbJoursparMois[mois - 1]) {
        return 0; // Jour invalide
    }

    return 1; // La date est valide
}

// Fonction pour v�rifier si une heure et une minute sont valides
int HeureValide(int heure, int minute) {
    // V�rifie si l'heure est dans la plage autoris�e et si les minutes sont valides
    return (heure >= HOUR_MIN && heure <= HOUR_MAX) && (minute >= MINUTE_MIN && minute <= MINUTE_MAX);
}

// Fonction pour v�rifier si une dur�e (heure et minute) est valide
int DureeValide(int heure, int minute) {
    // V�rifie si l'heure est dans la plage autoris�e, si les minutes sont valides et si la dur�e n'est pas �gale � z�ro
    return (heure >= HOUR_MIN && heure <= HOUR_MAX) && (minute >= MINUTE_MIN && minute <= MINUTE_MAX) && !(heure == 0 && minute == 0);
}

// Fonction pour v�rifier si une dur�e totale (heure + minute) est valide
int DureeTotaleValide(int heure, int minute) {
    const int TOTAL_MINUTES_MAX = 1439; // 23 heures et 59 minutes

    // Calcule le total en minutes
    int totalMinutes = heure * 60 + minute;

    // V�rifie si la dur�e totale est dans la plage autoris�e
    return totalMinutes > 0 && totalMinutes <= TOTAL_MINUTES_MAX;
}