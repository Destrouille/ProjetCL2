#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "partie3.h"
#include "tempsvalide.h"

// D�finition d'une constante pour la taille maximale des cha�nes de caract�res
#define MAX_CHAR 51

// D�finition des noms de fichiers de log et de sauvegarde
const char *LOG = "log3.txt";
const char *SAV = "sauvegarde.txt";

// D�claration et initialisation des compteurs de contacts et de rendez-vous
int nombrecontact = 0, nombrerdv = 0;

// Fonction pour convertir une cha�ne de caract�res en minuscules
char *minuscule(const char *nom_prenom) {
    if (nom_prenom == NULL) {
        fprintf(stderr, "Pointeur NULL passe � la fonction minuscule.\n");
        exit(EXIT_FAILURE);
    }

    // Allocation de m�moire pour la cha�ne r�sultante
    size_t length = strlen(nom_prenom);
    char *result = (char *)malloc(length + 1);

    if (result == NULL) {
        fprintf(stderr, "Allocation de memoire a echoue.\n");
        exit(EXIT_FAILURE);
    }

    // Conversion en minuscules
    for (size_t i = 0; i < length; i++) {
        result[i] = tolower((unsigned char)nom_prenom[i]);
    }

    result[length] = '\0';

    return result;
}

// Fonction de recherche dans l'agenda
t_recherchecontact Recherche(t_agenda *agenda, char *nom, char *prenom, int log) {
    t_recherchecontact r;
    r.current = agenda->contacts[0];
    r.prec = agenda->contacts[0];
    r.niveau = 4;

    clock_t debut, fin;
    char time_lvl0[15];
    char time_all_levels[15];
    FILE *log_file = NULL;
    char format[] = "%c\t%s\t%s\n";

    // Ouverture du fichier de log si n�cessaire
    if (log == 0) {
        log_file = fopen(LOG, "a");
        debut = clock();
    }

    // Cr�ation de la cha�ne nom_prenom en minuscules
    char nom_prenom_lower[MAX_CHAR];
    strcpy(nom_prenom_lower, minuscule(nom));
    strcat(nom_prenom_lower, "_");
    strcat(nom_prenom_lower, minuscule(prenom));

    // Recherche directe au niveau 0
    while (r.current != NULL) {
        int comp = strcmp(r.current->nom_prenom, nom_prenom_lower);
        if (comp == 0) {
            r.niveau = -1;
            break;
        } else if (comp < 0) {
            r.prec = r.current;
            r.current = r.current->next[0];
        } else {
            break;
        }
    }

    // Enregistrement du temps de la recherche au niveau 0 dans le fichier de log
    if (log == 0) {
        fin = clock();
        sprintf(time_lvl0, "%.6f", ((double)(fin - debut)) / CLOCKS_PER_SEC * 1000000);

        debut = clock();
    }

    // Recherche aux niveaux 4, 3, 2 et 1
    for (int i = 4; i >= 1; i--) {
        r.niveau = i;
        r.current = (i == 4) ? agenda->contacts[i - 1] : r.prec;

        char val[MAX_CHAR];
        char cur[MAX_CHAR];
        strncpy(val, nom_prenom_lower, i);
        val[i] = '\0';

        while (r.current != NULL) {
            strncpy(cur, r.current->nom_prenom, i);
            cur[i] = '\0';

            int comp = strcmp(cur, val);
            if (comp == 0) {
                r.niveau = i - 1;
                break;
            } else if (comp < 0) {
                r.prec = r.current;
                r.current = r.current->next[0];
            } else {
                break;
            }
        }
    }

    // Enregistrement du temps de la recherche pour tous les niveaux dans le fichier de log
    if (log == 0) {
        fin = clock();
        sprintf(time_all_levels, "%.6f", ((double)(fin - debut)) / CLOCKS_PER_SEC * 1000000);

        fprintf(log_file, format, nom[0], time_lvl0, time_all_levels);
        fclose(log_file);
    }

    return r;
}

// Fonction d'affichage des rendez-vous
void afficherRendezVous(t_rendezvous *rendez_vous) {
    t_rendezvous *rdv = rendez_vous;

    if (rdv == NULL) {
        printf("Pas de rendez-vous\n");
        return;
    }

    while (rdv != NULL) {
        // On affiche la date du rendez-vous
        printf("Date : %02d/%02d/%04d\n", rdv->jour, rdv->mois, rdv->annee);

        // On affiche l'heure du rendez-vous
        printf("Heure : %02d:%02d\n", rdv->heure, rdv->minute);

        // On affiche la dur�e du rendez-vous
        printf("Duree : ");
        if (rdv->duree_heure != 0) {
            printf("%d heure%s", rdv->duree_heure, (rdv->duree_heure > 1) ? "s" : "");
            if (rdv->duree_minute != 0) {
                printf(" et ");
            }
        }
        if (rdv->duree_minute != 0) {
            printf("%d minute%s", rdv->duree_minute, (rdv->duree_minute > 1) ? "s" : "");
        }
        printf("\n");

        // On affiche l'objet du rendez-vous
        printf("Objet : %s\n", rdv->objet);
        printf("-------------\n");

        rdv = rdv->next;
    }
}

// Fonction pour cr�er un contact avec les informations fournies
t_contact *creerContact(char *nom, char *prenom, int max_level) {
    // Allocation de m�moire pour le contact
    t_contact *contact = (t_contact *)malloc(sizeof(t_contact));

    if (contact == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour le contact.\n");
        exit(EXIT_FAILURE);
    }

    // Allocation de m�moire pour le nom du contact
    contact->nom = (char *)malloc(strlen(nom) + 1);
    if (contact->nom == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour le nom du contact.\n");
        free(contact);
        exit(EXIT_FAILURE);
    }
    strcpy(contact->nom, nom);

    // Allocation de m�moire pour le pr�nom du contact
    contact->prenom = (char *)malloc(strlen(prenom) + 1);
    if (contact->prenom == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour le prenom du contact.\n");
        free(contact->nom);
        free(contact);
        exit(EXIT_FAILURE);
    }
    strcpy(contact->prenom, prenom);

    // Allocation de m�moire pour le nom_prenom du contact
    contact->nom_prenom = (char *)malloc(strlen(nom) + strlen(prenom) + 2);
    if (contact->nom_prenom == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour le nom_prenom du contact.\n");
        free(contact->nom);
        free(contact->prenom);
        free(contact);
        exit(EXIT_FAILURE);
    }
    strcpy(contact->nom_prenom, minuscule(nom));
    strcat(contact->nom_prenom, "_");
    strcat(contact->nom_prenom, minuscule(prenom));

    // Initialisation des autres champs du contact
    contact->rendezvous = NULL;
    contact->max_level = max_level;

    // Allocation de m�moire pour les pointeurs suivants
    contact->next = (t_contact **)malloc(max_level * sizeof(t_contact *));
    if (contact->next == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour les pointeurs suivants du contact.\n");
        free(contact->nom);
        free(contact->prenom);
        free(contact->nom_prenom);
        free(contact);
        exit(EXIT_FAILURE);
    }

    // Initialisation des pointeurs suivants � NULL
    for (int i = 0; i < max_level; i++) {
        contact->next[i] = NULL;
    }

    return contact;
}

// Fonction pour ajouter un contact tri� dans l'agenda
void ajoutContactTri(t_agenda *agenda, t_contact *contact, t_contact *prec, t_contact *suiv) {
    if (prec != NULL) {
        // Copie des pointeurs suivants de prec vers contact
        for (int i = 0; i < contact->max_level && i < agenda->max_level; i++) {
            contact->next[i] = prec->next[i];
        }

        // Mise � jour des pointeurs suivants de prec vers contact
        for (int i = contact->max_level - 1; i >= 0 && i < agenda->max_level; i--) {
            prec->next[i] = contact;
        }

        // �change des donn�es entre prec et contact si n�cessaire
        if (strcmp(prec->nom_prenom, contact->nom_prenom) > 0) {
            // �change des cha�nes de caract�res
            char *temp_str;

            temp_str = prec->nom;
            prec->nom = contact->nom;
            contact->nom = temp_str;

            temp_str = prec->prenom;
            prec->prenom = contact->prenom;
            contact->prenom = temp_str;

            temp_str = prec->nom_prenom;
            prec->nom_prenom = contact->nom_prenom;
            contact->nom_prenom = temp_str;

            // �change des listes de rendez-vous
            t_rendezvous *temp_rdv;
            temp_rdv = prec->rendezvous;
            prec->rendezvous = contact->rendezvous;
            contact->rendezvous = temp_rdv;
        }
    } else {
        // Copie des pointeurs suivants de l'agenda vers contact
        for (int i = 0; i < contact->max_level && i < agenda->max_level; i++) {
            contact->next[i] = agenda->contacts[i];
        }

        // Mise � jour des pointeurs suivants de l'agenda vers contact
        for (int i = contact->max_level - 1; i >= 0 && i < agenda->max_level; i--) {
            agenda->contacts[i] = contact;
        }
    }
    // Mise � jour du nombre total de contacts dans l'agenda
    nombrecontact++;
}

// Fonction pour cr�er un rendez-vous et l'ajouter � un contact
t_rendezvous *creerEtAjouterRendezVous(t_contact *contact, int jour, int mois, int annee, int heure, int minute, int duree_heure, int duree_minute, char *objet) {
    // Allocation de m�moire pour le rendez-vous
    t_rendezvous *rdv = (t_rendezvous *)malloc(sizeof(t_rendezvous));
    if (rdv == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour le rendez-vous.\n");
        exit(EXIT_FAILURE);
    }

    // Initialisation des champs du rendez-vous avec les valeurs fournies
    rdv->jour = jour;
    rdv->mois = mois;
    rdv->annee = annee;
    rdv->heure = heure;
    rdv->minute = minute;
    rdv->duree_heure = duree_heure;
    rdv->duree_minute = duree_minute;

    // Allocation de m�moire pour la cha�ne d'objet
    rdv->objet = (char *)malloc(strlen(objet) + 1);
    if (rdv->objet == NULL) {
        fprintf(stderr, "Erreur d'allocation memoire pour l'objet du rendez-vous.\n");
        free(rdv);
        exit(EXIT_FAILURE);
    }
    strcpy(rdv->objet, objet);

    // Initialisation du pointeur suivant � NULL
    rdv->next = NULL;

    // Ajout du rendez-vous � la liste des rendez-vous du contact
    rdv->next = contact->rendezvous;
    contact->rendezvous = rdv;

    // Mise � jour du nombre total de rendez-vous
    nombrerdv++;

    // Retourne le pointeur vers le rendez-vous cr��
    return rdv;
}

// Fonction pour supprimer un rendez-vous d'un contact
void SuprRendezVous(t_contact *contact, int nb) {
    if (contact == NULL || nb <= 0) {
        fprintf(stderr, "Param�tres invalides dans SuprRendezVous.\n");
        return;
    }

    t_rendezvous *rdv = contact->rendezvous;
    t_rendezvous *rdv_prec = NULL;

    // Cas sp�cial pour le premier rendez-vous
    if (nb == 1) {
        contact->rendezvous = rdv->next;
    } else {
        int i;
        for (i = 0; i < nb - 1 && rdv != NULL; i++) {
            rdv_prec = rdv;
            rdv = rdv->next;
        }

        // V�rification de l'existence du rendez-vous � supprimer
        if (rdv == NULL) {
            fprintf(stderr, "Le rendez-vous � supprimer n'existe pas.\n");
            return;
        }

        // Mise � jour des pointeurs pour retirer le rendez-vous de la liste
        if (rdv_prec != NULL) {
            rdv_prec->next = rdv->next;
        } else {
            contact->rendezvous = rdv->next;
        }
    }

    printf("Rendez-vous supprime :\n");
    afficherRendezVous(rdv); // Affichage du rendez-vous supprim�
    free(rdv->objet);
    free(rdv);
    nombrerdv--;
}

// Fonction pour v�rifier l'existence du fichier de sauvegarde
int VerifierSauvegarde() {
    FILE *fichier = fopen(SAV, "a+");

    if (fichier != NULL) {
        fclose(fichier);
        return 0; // Succ�s : Le fichier existe et on peut le lire et �crire
    } else {
        return 1; // �chec : Le fichier n'existe pas ou on ne peut pas le lire et �crire
    }
}

// Fonction pour exporter les contacts et rendez-vous dans un fichier de sauvegarde
void ExportContactRdv(t_agenda *agenda) {
    FILE *f = fopen(SAV, "w"); // Ouvre le fichier en mode �criture
    if (f == NULL) {
        perror("Erreur lors de l'ouverture du fichier de sauvegarde");
        return;
    }

    t_contact *contact = agenda->contacts[0];

    while (contact != NULL) {
        t_rendezvous *rdv = contact->rendezvous;

        while (rdv != NULL) {
            // �criture des informations dans le fichier
            fprintf(f, "%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n",
                    contact->nom, contact->prenom,
                    rdv->jour, rdv->mois, rdv->annee,
                    rdv->heure, rdv->minute,
                    rdv->duree_heure, rdv->duree_minute,
                    rdv->objet);
            rdv = rdv->next;
        }

        contact = contact->next[0];
    }

    fclose(f); // Ferme le fichier
}

// Fonction pour importer les contacts et rendez-vous depuis un fichier de sauvegarde
void ImportContactRdv(t_agenda *agenda) {
    FILE *f = fopen(SAV, "r");
    if (f == NULL) {
        perror("Erreur lors de l'ouverture du fichier de sauvegarde");
        return;
    }

    char line[256];
    char *nom = NULL, *prenom = NULL, *objet = NULL;
    int jour, mois, annee, heure, minutes, heure2, minutes2;
    t_contact *contact;
    t_rendezvous *rdv;
    t_recherchecontact search;

    while (fgets(line, sizeof(line), f) != NULL) {
        // Suppression du caract�re de fin de ligne
        for (int i = 0; i < strlen(line); i++) {
            if (line[i] == '\n') {
                line[i] = '\0';
            }
        }

        // Extraction des informations de la ligne
        nom = strtok(line, "\t");
        prenom = strtok(NULL, "\t");
        jour = atoi(strtok(NULL, "\t"));
        mois = atoi(strtok(NULL, "\t"));
        annee = atoi(strtok(NULL, "\t"));
        heure = atoi(strtok(NULL, "\t"));
        minutes = atoi(strtok(NULL, "\t"));
        heure2 = atoi(strtok(NULL, "\t"));
        minutes2 = atoi(strtok(NULL, "\t"));
        objet = strtok(NULL, "\t");

        // Recherche du contact dans l'agenda
        search = Recherche(agenda, nom, prenom, 1);

        if (search.niveau != -1) {
            // Cr�ation du contact si n�cessaire
            contact = creerContact(nom, prenom, search.niveau);
            ajoutContactTri(agenda, contact, search.prec, search.current);

            // Ajout du rendez-vous au contact
            if (jour != 0) {
                rdv = creerEtAjouterRendezVous(contact, jour, mois, annee, heure, minutes, heure2, minutes2, objet);
            }
        } else {
            // Ajout du rendez-vous au contact existant
            if (jour != 0) {
                rdv = creerEtAjouterRendezVous(search.current, jour, mois, annee, heure, minutes, heure2, minutes2, objet);
            }
        }
    }

    fclose(f);
}

// Fonction pour saisir une cha�ne de caract�res valide depuis l'entr�e standard
char *scanString(char *question) {
    char *texte = NULL;
    int taille = 0;
    int capacite = 10; // Capacit� initiale du tableau dynamique
    char caractere;

    printf("%s", question);

    // Allocation de m�moire pour la cha�ne de caract�res
    texte = (char *)malloc(capacite * sizeof(char));
    if (texte == NULL) {
        printf("Erreur d'allocation de memoire.\n");
        exit(EXIT_FAILURE);
    }

    // Lecture de caract�res depuis l'entr�e standard
    while ((caractere = getchar()) != '\n' || taille < 3) {
        if ((caractere >= 'a' && caractere <= 'z') ||
            (caractere >= 'A' && caractere <= 'Z') ||
            caractere == ' ' || caractere == '\'' || caractere == '-') {
            // V�rification de la capacit� et ajustement si n�cessaire
            if (taille == capacite - 1) {
                capacite *= 2; // Double la capacit� si n�cessaire
                texte = (char *)realloc(texte, capacite * sizeof(char));
                if (texte == NULL) {
                    printf("Erreur d'allocation de memoire.\n");
                    exit(EXIT_FAILURE);
                }
            }
            texte[taille++] = caractere;
        } else {
            printf("\b"); // Retour en arri�re si un caract�re invalide est saisi
        }
    }

    // Ajustement de la m�moire pour le caract�re de fin de cha�ne
    texte = (char *)realloc(texte, (taille + 1) * sizeof(char));
    if (texte == NULL) {
        printf("Erreur d'allocation de memoire.\n");
        exit(EXIT_FAILURE);
    }

    // Ajout du caract�re de fin de cha�ne
    texte[taille] = '\0';

    return texte;
}

// Fonction pour cr�er un agenda
t_agenda *creerAgenda(void) {
    // Allocation de m�moire pour l'agenda
    t_agenda *agenda = (t_agenda *)malloc(sizeof(t_agenda));
    if (agenda == NULL) {
        fprintf(stderr, "Erreur d'allocation de m�moire pour l'agenda.\n");
        exit(EXIT_FAILURE);
    }

    // Allocation de m�moire pour les contacts de l'agenda
    agenda->contacts = (t_contact **)malloc(4 * sizeof(t_contact *));
    if (agenda->contacts == NULL) {
        fprintf(stderr, "Erreur d'allocation de memoire pour les contacts de l'agenda.\n");
        free(agenda);
        exit(EXIT_FAILURE);
    }

    // Initialisation des pointeurs des contacts � NULL
    for (int i = 0; i < 4; i++) {
        agenda->contacts[i] = NULL;
    }

    // Attribution de la profondeur maximale
    agenda->max_level = 4;

    return agenda;
}
// Afficher l'ensemble des cellules de la liste pour un niveau donn�
void afficherniveau(t_agenda *agenda, int level) {
    if (level < 0 || level >= agenda->max_level) {
        fprintf(stderr, "Niveau invalide : %d\n", level);
        return;
    }

    printf("[Agenda_%d @-]", level);

    t_contact *contact = agenda->contacts[level];
    if (contact == NULL) {
        printf("-->NULL\n");
        return;
    }

    while (contact != NULL) {
        printf("-->[%s|@-]", contact->nom_prenom);
        contact = contact->next[level];
    }

    printf("-->NULL\n");
}

// Afficher tous les niveaux de la liste
void afficherAgenda(t_agenda *agenda) {
    for (int i = 0; i < agenda->max_level; i++) {
        afficherniveau(agenda, i);
    }
}

// Afficher le menu
void afficherMenu() {
    printf("\nMenu :\n");
    printf("1. Creer un contact\n");
    printf("2. Ajouter un rendez-vous\n");
    printf("3. Supprimer un rendez-vous\n");
    printf("4. Afficher un rendez-vous\n");
    printf("5. Afficher l'agenda\n");
    printf("6. Charger la sauvegarde\n");
    printf("7. Quitter\n");
    printf("Choix : ");
}

// Cr�er un contact � partir du menu
void creerContactMenu(t_agenda *agenda) {
    printf("Nom : ");
    char *nom = scanString("");
    printf("Prenom : ");
    char *prenom = scanString("");

    // Ajouter le code pour cr�er un contact ici
    t_recherchecontact search = Recherche(agenda, nom, prenom, 1);

    if (search.niveau != -1) {
        t_contact *contact = creerContact(nom, prenom, search.niveau);
        ajoutContactTri(agenda, contact, search.prec, search.current);
        printf("Contact cree avec succ�s.\n");
    } else {
        printf("Le contact existe dej�.\n");
    }

    free(nom);
    free(prenom);
}

// Ajouter un rendez-vous � partir du menu
void ajouterRendezVousMenu(t_agenda *agenda) {
    printf("Nom : ");
    char *nom = scanString("");
    printf("Prenom : ");
    char *prenom = scanString("");

    t_recherchecontact search = Recherche(agenda, nom, prenom, 1);

    if (search.niveau != -1) {
        // Contact trouv�, ajouter un rendez-vous
        int jour, mois, annee, heure, minute, duree_heure, duree_minute;
        do {
            printf("Les informations de date, heure ou duree ne sont pas valides. Veuillez verifier vos saisies.\n");
            printf("Jour : ");
            scanf("%d", &jour);
            printf("Mois : ");
            scanf("%d", &mois);
            printf("Annee : ");
            scanf("%d", &annee);
            printf("Heure : ");
            scanf("%d", &heure);
            printf("Minute : ");
            scanf("%d", &minute);
            printf("Duree (heures) : ");
            scanf("%d", &duree_heure);
            printf("Duree (minutes) : ");
            scanf("%d", &duree_minute);
            getchar();  // Pour consommer le caract�re de nouvelle ligne laiss� par scanf
        } while (!DateValide(jour, mois, annee) || !HeureValide(heure, minute) || !DureeValide(duree_heure, duree_minute) || !DureeTotaleValide(duree_heure, duree_minute));
        printf("Objet : ");
        char *objet = scanString("");

        t_contact *contact = search.current;
        t_rendezvous *rdv = creerEtAjouterRendezVous(contact, jour, mois, annee, heure, minute, duree_heure, duree_minute, objet);
        printf("Rendez-vous ajoute avec succ�s.\n");
    } else {
        printf("Contact non trouve. Ajoutez d'abord le contact.\n");
    }

    free(nom);
    free(prenom);
}

// Supprimer un rendez-vous � partir du menu
void supprimerRendezVousMenu(t_agenda *agenda) {
    printf("Nom : ");
    char *nom = scanString("");
    printf("Prenom : ");
    char *prenom = scanString("");

    t_recherchecontact search = Recherche(agenda, nom, prenom, 1);

    if (search.niveau != -1) {
        // Contact trouv�, supprimer un rendez-vous
        t_contact *contact = search.current;

        if (contact->rendezvous != NULL) {
            printf("Liste des rendez-vous :\n");
            afficherRendezVous(contact->rendezvous);

            printf("Entrez le numero du rendez-vous � supprimer : ");
            int numero;
            scanf("%d", &numero);

            SuprRendezVous(contact, numero);
            printf("Rendez-vous supprime avec succ�s.\n");
        } else {
            printf("Aucun rendez-vous � supprimer.\n");
        }
    } else {
        printf("Contact non trouve. Ajoutez d'abord le contact.\n");
    }

    free(nom);
    free(prenom);
}

// Afficher les rendez-vous � partir du menu
void afficherRendezVousMenu(t_agenda *agenda) {
    printf("Nom : ");
    char *nom = scanString("");
    printf("Prenom : ");
    char *prenom = scanString("");

    t_recherchecontact search = Recherche(agenda, nom, prenom, 1);

    if (search.niveau != -1) {
        // Contact trouv�, afficher les rendez-vous
        t_contact *contact = search.current;
        if (contact->rendezvous != NULL) {
            printf("Liste des rendez-vous :\n");
            afficherRendezVous(contact->rendezvous);
        } else {
            printf("Aucun rendez-vous � afficher.\n");
        }
    } else {
        printf("Contact non trouve. Ajoutez d'abord le contact.\n");
    }

    free(nom);
    free(prenom);
}

void chargerSauvegardeMenu(t_agenda *agenda) {
    if (VerifierSauvegarde() == 0) {
        printf("Chargement de la sauvegarde en cours...\n");
        ImportContactRdv(agenda);
        printf("Sauvegarde chargee avec succ�s.\n");
    } else {
        printf("Aucune sauvegarde trouvee.\n");
    }
}