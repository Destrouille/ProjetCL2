#include <stdbool.h>

#define MONTH_MIN 1
#define MONTH_MAX 12
#define HOUR_MIN 0
#define HOUR_MAX 23
#define MINUTE_MIN 0
#define MINUTE_MAX 59

int DateValide(int jour, int mois, int annee);
int HeureValide(int heure, int minute);
int DureeValide(int heure, int minute);
int DureeTotaleValide(int heure, int minute);