Projet de L2 : Soave Rapha�l, Callegari Nicolas, Colonna Walewski Armand.

Dans le main c du projet, vous pouvez trouver des mains relatifs aux diff�rentes parties du projet. Lorsque le programme est lanc�,l'utilisateur � le chois entre :
1. Cr�er un contact
2. Ajouter un rendez-vous
3. Supprimer un rendez-vous
4. Afficher un rendez-vous
5. Afficher l'agenda
6. Quitter
Apr�s cela, il lui suffit d'entrer la lettre correspondant � ce qu'il veut effectuer.
Il y a une petite erreur lorsque l'utilisateur rentre la date et l'heure du rendez-vous pour la premi�re fois. Le programme dit qu'elle est incorrecte mais ce n'est que visuel et il ne faut pas y faire attention.
Les fonctions permettant de charger la sauvegarde ont �t� �crites mais nous n'avons pas r�ussi � les faire bien s'effectu�es.