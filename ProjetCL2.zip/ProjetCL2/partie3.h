#ifndef UNTITLED_PARTIE3_H
#define UNTITLED_PARTIE3_H

// Structure d�di�e au stockage d'un rendez-vous
typedef struct s_rendezvous {
    int jour, mois, annee;          // Informations sur la date du rendez-vous
    int heure, minute;              // Informations sur l'heure du rendez-vous
    int duree_heure, duree_minute;  // Informations sur la dur�e du rendez-vous
    char *objet;                     // Objet du rendez-vous (cha�ne de caract�res)
    struct s_rendezvous *next;       // Pointeur vers le prochain rendez-vous dans la liste
} t_rendezvous;

// Structure d�di�e au stockage d'un contact
typedef struct s_contact {
    char *nom;                       // Nom du contact (cha�ne de caract�res)
    char *prenom;                    // Pr�nom du contact (cha�ne de caract�res)
    char *nom_prenom;                // Concat�nation de nom et pr�nom pour la recherche
    struct s_rendezvous *rendezvous;  // Pointeur vers un tableau dynamique de rendez-vous associ�s � ce contact
    struct s_contact **next;         // Tableau dynamique de pointeurs vers les contacts suivants � diff�rents niveaux
    int max_level;                   // Nombre maximum de niveaux dans la structure de l'agenda
} t_contact;

// Structure de l'agenda
typedef struct s_agenda {
    t_contact **contacts;  // Tableau dynamique de pointeurs vers les contacts (niveaux de l'agenda)
    int max_level;         // Nombre de niveaux dans la liste d'agenda
} t_agenda;

// Structure pour la recherche d'un contact dans l'agenda
typedef struct s_recherchecontact {
    t_contact *prec;   // Pointeur vers le contact pr�c�dent lors de la recherche
    t_contact *current;  // Pointeur vers le contact courant lors de la recherche
    int niveau;         // Niveau actuel de la recherche
} t_recherchecontact;

char *minuscule(const char *nom_prenom);
t_recherchecontact Recherche(t_agenda *agenda, char *nom, char *prenom, int log);

void afficherRendezVous(t_rendezvous *rendez_vous);

t_contact *creerContact(char *nom, char *prenom, int max_level);

void ajoutContactTri(t_agenda *agenda, t_contact *contact, t_contact *prec, t_contact *suiv);

t_rendezvous *
creerEtAjouterRendezVous(t_contact *contact, int jour, int mois, int annee, int heure, int minute, int duree_heure, int duree_minute, char *objet);

void SuprRendezVous(t_contact *contact, int nb);

int VerifierSauvegarde();

void ExportContactRdv(t_agenda *agenda);

void ImportContactRdv(t_agenda *agenda);

char *scanString(char *question);
t_agenda *creerAgenda(void);
void afficherniveau(t_agenda *agenda, int level);
void afficherAgenda(t_agenda *agenda);


void afficherMenu();
void creerContactMenu(t_agenda *agenda);
void ajouterRendezVousMenu(t_agenda *agenda);
void supprimerRendezVousMenu(t_agenda *agenda);
void afficherRendezVousMenu(t_agenda *agenda);


#endif // UNTITLED_CELL_H